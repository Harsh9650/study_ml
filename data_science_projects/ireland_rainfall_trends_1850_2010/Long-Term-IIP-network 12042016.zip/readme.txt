This zip file contains data and metadata for the Long term (1850-2010) Island of Ireland Precipitation (IIP) network.

There are 25 files, NAME.csv, containing monthly rainfall totals for each station in the network, each of these files also contains information on the station location and altitude.

The file IIP_National series.csv contains the rainfall averaged over the 25 stations.

The file IIP station metadata.pdf contains station metadata and details of how the series were constructed.